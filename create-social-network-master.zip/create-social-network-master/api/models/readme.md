# Models

Models are fancy constructors compiled from Schema definitions. An instance of a model is called a document. Models are responsible for creating and reading documents from the underlying MongoDB database.

https://mongoosejs.com/docs/models.html

### Referencing documents in other collections

https://mongoosejs.com/docs/populate.html
