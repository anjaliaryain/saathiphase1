# Resolvers

Resolver is a function that connects schema fields and types to our NodeJS backend. It provides the instructions for turning a GraphQL operation into data. We are using them to retrieve or write data to our MongoDB database.

https://www.apollographql.com/docs/graphql-tools/resolvers/
